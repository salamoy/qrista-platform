import { useState, createContext, useContext, ReactNode } from 'react';
import { useToast } from '@/hooks/use-toast';

type User = {
  name: string;
  email: string;
  plan?: 'monthly' | 'sixmonth' | 'yearly';
} | null;

type AuthContextType = {
  user: User;
  login: (email: string) => void;
  logout: () => void;
  isLoading: boolean;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const login = (email: string) => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setUser({ name: "Demo User", email, plan: 'yearly' });
      setIsLoading(false);
      toast({
        title: "Welcome back!",
        description: "Successfully logged in to Qrista.",
      });
    }, 1000);
  };

  const logout = () => {
    setUser(null);
    toast({
      title: "Logged out",
      description: "See you soon!",
    });
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}