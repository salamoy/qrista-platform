import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  ar: {
    translation: {
      "nav.features": "المميزات",
      "nav.pricing": "الأسعار",
      "nav.login": "تسجيل الدخول",
      "nav.signup": "ابدأ الفترة التجريبية",
      "hero.title": "رموز QR ذكية",
      "hero.subtitle": "تواصل مع عملائك فوراً. تتبع المسح، صمم رموزك، وزد تفاعل واتساب.",
      "hero.cta": "ابدأ تجربة مجانية 7 أيام",
      "pricing.monthly": "شهري",
      "pricing.sixmonth": "6 أشهر",
      "pricing.yearly": "سنوي",
      "pricing.most_popular": "الأكثر طلباً",
      "pricing.per_month": "/ شهر",
      "stats.total_scans": "إجمالي المسح",
      "stats.whatsapp_clicks": "نقرات واتساب",
      "dash.create_qr": "إنشاء رمز QR",
      "dash.whatsapp_number": "رقم واتساب",
      "dash.initials": "الأحرف في الوسط",
      "dash.upload_logo": "رفع الشعار",
      "dash.preview": "معاينة",
      "public.connect": "تواصل عبر واتساب",
      "public.scan_me": "امسح للتواصل"
    }
  },
  en: {
    translation: {
      "nav.features": "Features",
      "nav.pricing": "Pricing",
      "nav.login": "Login",
      "nav.signup": "Start Free Trial",
      "hero.title": "Smart QR Codes for",
      "hero.subtitle": "Connect with customers instantly. Track scans, customize designs, and drive WhatsApp engagement.",
      "hero.cta": "Start 7-Day Free Trial",
      "pricing.monthly": "Monthly",
      "pricing.sixmonth": "6 Months",
      "pricing.yearly": "Yearly",
      "pricing.most_popular": "Most Popular",
      "pricing.per_month": "/ month",
      "stats.total_scans": "Total Scans",
      "stats.whatsapp_clicks": "WhatsApp Clicks",
      "dash.create_qr": "Create QR Code",
      "dash.whatsapp_number": "WhatsApp Number",
      "dash.initials": "Center Initials",
      "dash.upload_logo": "Upload Logo",
      "dash.preview": "Preview",
      "public.connect": "Connect on WhatsApp",
      "public.scan_me": "Scan to Connect"
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: "ar", // Set Arabic as default
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;