import { Link, useLocation } from 'wouter';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Globe, Menu, X } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import logo from '@assets/generated_images/modern_abstract_logo_for_qrista_saas_with_qr_code_elements.png';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

export function Navbar() {
  const { t, i18n } = useTranslation();
  const { user, logout } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const [location] = useLocation();

  const toggleLanguage = () => {
    const newLang = i18n.language === 'en' ? 'ar' : 'en';
    i18n.changeLanguage(newLang);
    document.documentElement.dir = newLang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = newLang;
  };

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Don't show navbar on public QR page
  if (location.startsWith('/qr/')) return null;

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white/80 backdrop-blur-md shadow-sm py-4' : 'bg-transparent py-6'}`}>
      <div className="container mx-auto px-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
            <div className="relative w-10 h-10 overflow-hidden rounded-xl bg-gradient-to-br from-primary to-secondary p-[2px]">
              <div className="w-full h-full bg-white rounded-[10px] flex items-center justify-center">
                <img src={logo} alt="Qrista" className="w-8 h-8 object-contain" />
              </div>
            </div>
            <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">Qrista</span>
        </Link>

        <div className="hidden md:flex items-center gap-8">
          <a href="#features" className="text-foreground/80 hover:text-primary transition-colors font-medium">{t('nav.features')}</a>
          <a href="#pricing" className="text-foreground/80 hover:text-primary transition-colors font-medium">{t('nav.pricing')}</a>
        </div>

        <div className="hidden md:flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={toggleLanguage} className="rounded-full hover:bg-primary/10 text-primary">
            <Globe className="w-5 h-5" />
          </Button>
          
          {user ? (
             <div className="flex items-center gap-4">
               <Link href="/dashboard">
                 <Button variant="default" className="rounded-full px-6 shadow-lg shadow-primary/25 bg-gradient-to-r from-primary to-secondary hover:opacity-90 border-0">
                   Dashboard
                 </Button>
               </Link>
               <Button variant="ghost" onClick={logout}>Logout</Button>
             </div>
          ) : (
            <>
              <Link href="/login">
                <Button variant="ghost" className="font-medium hover:text-primary">{t('nav.login')}</Button>
              </Link>
              <Link href="/signup">
                <Button className="rounded-full px-6 shadow-lg shadow-primary/25 bg-gradient-to-r from-primary to-secondary hover:opacity-90 border-0">
                  {t('nav.signup')}
                </Button>
              </Link>
            </>
          )}
        </div>

        {/* Mobile Menu */}
        <div className="md:hidden flex items-center gap-2">
           <Button variant="ghost" size="icon" onClick={toggleLanguage} className="rounded-full text-primary">
            <Globe className="w-5 h-5" />
          </Button>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="w-6 h-6" />
              </Button>
            </SheetTrigger>
            <SheetContent>
              <div className="flex flex-col gap-6 mt-10">
                <a href="#features" className="text-lg font-medium">{t('nav.features')}</a>
                <a href="#pricing" className="text-lg font-medium">{t('nav.pricing')}</a>
                <hr className="border-border/50" />
                {user ? (
                  <>
                    <Link href="/dashboard">
                      <Button className="w-full bg-gradient-to-r from-primary to-secondary">Dashboard</Button>
                    </Link>
                    <Button variant="outline" onClick={logout} className="w-full">Logout</Button>
                  </>
                ) : (
                  <>
                    <Link href="/login">
                       <Button variant="outline" className="w-full">{t('nav.login')}</Button>
                    </Link>
                    <Link href="/signup">
                      <Button className="w-full bg-gradient-to-r from-primary to-secondary">{t('nav.signup')}</Button>
                    </Link>
                  </>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}