import { useState, useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { QRCodeSVG } from 'qrcode.react';
import { Download, Share2, MessageCircle, LayoutDashboard, Settings, LogOut, Upload, Image as ImageIcon, Link as LinkIcon, AlertCircle, X, Trash2, User, Save, CreditCard, Calendar, Mail } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";

const mockData = [
  { name: 'Mon', scans: 40, clicks: 24 },
  { name: 'Tue', scans: 30, clicks: 13 },
  { name: 'Wed', scans: 20, clicks: 98 },
  { name: 'Thu', scans: 27, clicks: 39 },
  { name: 'Fri', scans: 18, clicks: 48 },
  { name: 'Sat', scans: 23, clicks: 38 },
  { name: 'Sun', scans: 34, clicks: 43 },
];

export default function Dashboard() {
  const { t } = useTranslation();
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const logoInputRef = useRef<HTMLInputElement>(null);
  const profileInputRef = useRef<HTMLInputElement>(null);
  const publicImageInputRef = useRef<HTMLInputElement>(null);
  
  const [businessName, setBusinessName] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [initials, setInitials] = useState('');
  const [color, setColor] = useState('#2979FF');
  const [logoImg, setLogoImg] = useState<string | null>(null);
  const [profileImg, setProfileImg] = useState<string | null>(null);
  const [publicImages, setPublicImages] = useState<string[]>([]);
  const [isExpired, setIsExpired] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Load saved data on mount
  useEffect(() => {
    const savedName = localStorage.getItem('qrista_business_name');
    const savedWhatsapp = localStorage.getItem('qrista_whatsapp');
    const savedInitials = localStorage.getItem('qrista_initials');
    const savedColor = localStorage.getItem('qrista_color');
    const savedLogo = localStorage.getItem('qrista_logo');
    const savedProfile = localStorage.getItem('qrista_profile');
    const savedPublicImages = localStorage.getItem('qrista_public_images');
    const savedStatus = localStorage.getItem('qrista_subscription_status');

    if (savedName) setBusinessName(savedName);
    if (savedWhatsapp) setWhatsapp(savedWhatsapp);
    if (savedInitials) setInitials(savedInitials);
    if (savedColor) setColor(savedColor);
    if (savedLogo) setLogoImg(savedLogo);
    if (savedProfile) setProfileImg(savedProfile);
    if (savedPublicImages) setPublicImages(JSON.parse(savedPublicImages));
    if (savedStatus) setIsExpired(savedStatus === 'expired');
  }, []);

  const handleSave = () => {
    localStorage.setItem('qrista_business_name', businessName);
    localStorage.setItem('qrista_whatsapp', whatsapp);
    localStorage.setItem('qrista_initials', initials);
    localStorage.setItem('qrista_color', color);
    localStorage.setItem('qrista_subscription_status', isExpired ? 'expired' : 'active');
    if (logoImg) localStorage.setItem('qrista_logo', logoImg);
    if (profileImg) localStorage.setItem('qrista_profile', profileImg);
    localStorage.setItem('qrista_public_images', JSON.stringify(publicImages));
    
    toast({
      title: "تم الحفظ بنجاح",
      description: "تم تحديث جميع الإعدادات وحفظها.",
      className: "bg-green-50 border-green-200 text-green-800"
    });
  };

  if (!user) {
    setLocation('/login');
    return null;
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, setter: (val: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { // 2MB limit
        toast({
          title: "الملف كبير جداً",
          description: "يرجى رفع صورة بحجم أقل من 2 ميجابايت.",
          variant: "destructive"
        });
        return;
      }
      const reader = new FileReader();
      reader.onload = (e) => setter(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handlePublicImagesUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length + publicImages.length > 10) {
      toast({
        title: "تجاوزت الحد المسموح",
        description: "يمكنك رفع 10 صور كحد أقصى.",
        variant: "destructive"
      });
      return;
    }

    files.forEach(file => {
      if (file.size > 2 * 1024 * 1024) return;
      const reader = new FileReader();
      reader.onload = (e) => {
        setPublicImages(prev => {
          if (prev.length >= 10) return prev;
          return [...prev, e.target?.result as string];
        });
      };
      reader.readAsDataURL(file);
    });
  };

  const removePublicImage = (index: number) => {
    setPublicImages(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="min-h-screen bg-gray-50/50 pt-24 pb-12" dir="rtl">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Sidebar */}
          <aside className="w-full md:w-64 flex-shrink-0">
            <Card className="border-none shadow-lg shadow-gray-200/50 sticky top-24">
              <CardContent className="p-4">
                <div className="flex flex-col items-center gap-3 mb-8 p-2 text-center">
                  <div 
                    className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden cursor-pointer relative group border-2 border-primary/20"
                    onClick={() => profileInputRef.current?.click()}
                  >
                    {profileImg ? (
                      <img src={profileImg} className="w-full h-full object-cover" />
                    ) : (
                      <div className="text-primary font-bold text-2xl">{user.name.charAt(0)}</div>
                    )}
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <User className="w-6 h-6 text-white" />
                    </div>
                    <input 
                      type="file" 
                      ref={profileInputRef} 
                      className="hidden" 
                      accept="image/*"
                      onChange={(e) => handleImageUpload(e, setProfileImg)}
                    />
                  </div>
                  <div>
                    <p className="font-bold text-sm">{user.name}</p>
                    <p className="text-xs text-muted-foreground capitalize">{user.plan} Plan</p>
                  </div>
                </div>
                
                <nav className="space-y-1">
                  <Button variant="ghost" className="w-full justify-start gap-3 bg-primary/5 text-primary font-medium">
                    <LayoutDashboard className="w-4 h-4" /> لوحة التحكم
                  </Button>
                  
                  <Sheet open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
                    <SheetTrigger asChild>
                       <Button variant="ghost" className="w-full justify-start gap-3 hover:bg-gray-100">
                        <Settings className="w-4 h-4" /> الإعدادات
                      </Button>
                    </SheetTrigger>
                    <SheetContent side="right">
                      <SheetHeader>
                        <SheetTitle>إعدادات الحساب</SheetTitle>
                        <SheetDescription>
                          إدارة تفضيلات حسابك والاشتراك.
                        </SheetDescription>
                      </SheetHeader>
                      <div className="py-6 space-y-6">
                        {/* Account Info Section */}
                        <div className="space-y-4">
                          <h3 className="font-medium text-sm text-muted-foreground flex items-center gap-2">
                            <User className="w-4 h-4" /> معلومات الحساب
                          </h3>
                          <Card className="bg-gray-50 border-gray-100">
                            <CardContent className="p-4 space-y-3 text-sm">
                              <div className="flex items-center justify-between">
                                <span className="text-muted-foreground flex items-center gap-2">
                                  <Mail className="w-3 h-3" /> البريد الإلكتروني
                                </span>
                                <span className="font-medium">{user.email}</span>
                              </div>
                              <div className="flex items-center justify-between">
                                <span className="text-muted-foreground flex items-center gap-2">
                                  <CreditCard className="w-3 h-3" /> خطة الاشتراك
                                </span>
                                <span className="font-medium capitalize">{user.plan}</span>
                              </div>
                              <div className="flex items-center justify-between">
                                <span className="text-muted-foreground flex items-center gap-2">
                                  <AlertCircle className="w-3 h-3" /> الحالة
                                </span>
                                <span className={`font-bold px-2 py-0.5 rounded-full text-xs ${!isExpired ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                  {!isExpired ? 'نشط' : 'منتهي'}
                                </span>
                              </div>
                              <div className="flex items-center justify-between">
                                <span className="text-muted-foreground flex items-center gap-2">
                                  <Calendar className="w-3 h-3" /> تاريخ التجديد
                                </span>
                                <span className="font-medium">12/12/2025</span>
                              </div>
                            </CardContent>
                          </Card>
                        </div>
                        
                        <Separator />
                        
                        <div className="space-y-4">
                           <h3 className="font-medium text-sm text-muted-foreground">تفضيلات أخرى</h3>
                           <div className="flex items-center justify-between">
                             <Label>الإشعارات البريدية</Label>
                             <Switch defaultChecked />
                           </div>
                           <div className="flex items-center justify-between">
                             <Label>تنبيهات واتساب</Label>
                             <Switch defaultChecked />
                           </div>
                        </div>
                      </div>
                    </SheetContent>
                  </Sheet>

                  <Button variant="ghost" className="w-full justify-start gap-3 hover:bg-red-50 text-red-500 hover:text-red-600" onClick={logout}>
                    <LogOut className="w-4 h-4" /> تسجيل الخروج
                  </Button>
                </nav>

                <div className="mt-8 pt-6 border-t">
                  <div className="flex items-center justify-between mb-2">
                    <Label className="text-xs font-medium text-muted-foreground">حالة الاشتراك</Label>
                    <Switch 
                      checked={!isExpired} 
                      onCheckedChange={(c) => setIsExpired(!c)} 
                    />
                  </div>
                  <p className={`text-xs font-bold ${isExpired ? 'text-red-500' : 'text-green-500'}`}>
                    {isExpired ? 'منتهي الصلاحية' : 'نشط'}
                  </p>
                </div>
              </CardContent>
            </Card>
          </aside>

          {/* Main Content */}
          <main className="flex-1 space-y-8">
             {/* Header with Save Button */}
             <div className="flex justify-between items-center">
               <h1 className="text-2xl font-bold">لوحة المعلومات</h1>
               <Button onClick={handleSave} className="bg-green-600 hover:bg-green-700 text-white gap-2 shadow-lg shadow-green-600/20">
                 <Save className="w-4 h-4" />
                 حفظ التغييرات
               </Button>
             </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-4 md:gap-8">
              <Card className="border-none shadow-md bg-gradient-to-br from-primary to-blue-600 text-white">
                <CardContent className="p-6">
                  <p className="text-blue-100 text-sm font-medium mb-1">{t('stats.total_scans')}</p>
                  <h3 className="text-3xl font-bold">1,284</h3>
                </CardContent>
              </Card>
              <Card className="border-none shadow-md bg-white">
                <CardContent className="p-6">
                  <p className="text-muted-foreground text-sm font-medium mb-1">{t('stats.whatsapp_clicks')}</p>
                  <h3 className="text-3xl font-bold text-foreground">843</h3>
                </CardContent>
              </Card>
            </div>

            {/* Config Section */}
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Left Column: Configuration */}
              <div className="space-y-8">
                 <Card className="border-none shadow-sm">
                  <CardHeader>
                    <CardTitle>إعدادات رمز QR</CardTitle>
                    <CardDescription>تخصيص مظهر رمز الاستجابة السريعة</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="businessName">اسم العمل / المتجر</Label>
                      <Input 
                        id="businessName" 
                        placeholder="مطعم القمة" 
                        value={businessName}
                        onChange={(e) => setBusinessName(e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="whatsapp">{t('dash.whatsapp_number')}</Label>
                      <div className="relative">
                        <MessageCircle className="absolute right-3 top-3 w-4 h-4 text-muted-foreground" />
                        <Input 
                          id="whatsapp" 
                          placeholder="+966 50 123 4567" 
                          className="pr-10 text-left"
                          dir="ltr"
                          value={whatsapp}
                          onChange={(e) => setWhatsapp(e.target.value)}
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="initials">{t('dash.initials')}</Label>
                      <Input 
                        id="initials" 
                        placeholder="مثال: AB" 
                        maxLength={2}
                        className="text-center font-bold"
                        value={initials}
                        onChange={(e) => {
                          setInitials(e.target.value.toUpperCase());
                          if (e.target.value) setLogoImg(null); 
                        }}
                      />
                    </div>

                    <div className="space-y-2">
                       <Label>{t('dash.upload_logo')} (في وسط الرمز)</Label>
                       <div 
                         className="border-2 border-dashed border-gray-200 rounded-lg p-4 flex flex-col items-center justify-center cursor-pointer hover:border-primary/50 hover:bg-primary/5 transition-colors"
                         onClick={() => logoInputRef.current?.click()}
                       >
                         <input 
                           type="file" 
                           ref={logoInputRef} 
                           className="hidden" 
                           accept="image/*"
                           onChange={(e) => handleImageUpload(e, setLogoImg)}
                         />
                         {logoImg ? (
                           <img src={logoImg} className="h-10 w-10 object-contain mb-2" />
                         ) : (
                           <Upload className="w-8 h-8 text-muted-foreground mb-2" />
                         )}
                         <span className="text-xs text-muted-foreground">رفع الشعار</span>
                       </div>
                    </div>

                    <div className="space-y-2">
                      <Label>لون الرمز</Label>
                      <div className="flex gap-3">
                        {['#2979FF', '#7B61FF', '#00D4FF', '#FF4081', '#00C853'].map((c) => (
                          <button
                            key={c}
                            onClick={() => setColor(c)}
                            className={`w-8 h-8 rounded-full border-2 transition-all ${color === c ? 'border-gray-900 scale-110' : 'border-transparent'}`}
                            style={{ backgroundColor: c }}
                          />
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-none shadow-sm">
                  <CardHeader>
                    <CardTitle>محتوى الصفحة العامة</CardTitle>
                    <CardDescription>ما يراه العميل عند مسح الرمز</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-2">
                       <div className="flex justify-between items-center">
                          <Label>صور القائمة / المنتجات (حتى 10 صور)</Label>
                          <span className="text-xs text-muted-foreground">{publicImages.length}/10</span>
                       </div>
                       
                       <div className="grid grid-cols-3 gap-2 mb-4">
                          {publicImages.map((img, idx) => (
                            <div key={idx} className="relative aspect-square rounded-lg overflow-hidden border group">
                              <img src={img} className="w-full h-full object-cover" />
                              <button 
                                onClick={() => removePublicImage(idx)}
                                className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <X className="w-3 h-3" />
                              </button>
                            </div>
                          ))}
                          {publicImages.length < 10 && (
                            <div 
                              className="aspect-square border-2 border-dashed border-gray-200 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 transition-colors"
                              onClick={() => publicImageInputRef.current?.click()}
                            >
                              <ImageIcon className="w-6 h-6 text-muted-foreground mb-1" />
                              <span className="text-[10px] text-muted-foreground text-center">إضافة صورة</span>
                            </div>
                          )}
                       </div>
                       
                       <input 
                         type="file" 
                         ref={publicImageInputRef} 
                         className="hidden" 
                         accept="image/*"
                         multiple
                         onChange={handlePublicImagesUpload}
                       />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Right Column: Preview */}
              <div className="space-y-8">
                 <Card className="border-none shadow-sm overflow-hidden sticky top-32">
                  <CardHeader className="bg-gray-50/50 border-b border-gray-100">
                    <CardTitle>معاينة حية</CardTitle>
                  </CardHeader>
                  <CardContent className="p-8 flex flex-col items-center">
                    <div className="bg-white p-4 rounded-3xl shadow-lg mb-8 relative">
                      {/* Rounded corners styling wrapper for QR */}
                      <div className="relative">
                        <QRCodeSVG
                          value={window.location.origin + "/qr/demo"}
                          size={220}
                          fgColor={color}
                          level="H"
                          includeMargin={true}
                          imageSettings={logoImg ? {
                            src: logoImg,
                            x: undefined,
                            y: undefined,
                            height: 44,
                            width: 44,
                            excavate: true,
                          } : undefined}
                        />
                        {/* Overlay to create rounded dots effect visually (simple CSS hack for mockup) */}
                        <div className="absolute inset-0 pointer-events-none mix-blend-screen bg-white opacity-10" style={{borderRadius: '20px'}}></div>
                      </div>
                      
                      {initials && !logoImg && (
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-14 h-14 bg-white rounded-full flex items-center justify-center font-bold text-2xl border-4 border-white shadow-sm" style={{ color }}>
                          {initials}
                        </div>
                      )}
                    </div>
                    
                    <div className="flex gap-3 w-full max-w-xs mb-6">
                      <Button className="flex-1" variant="outline">
                        <Download className="w-4 h-4 ml-2" /> PNG
                      </Button>
                      <Button className="flex-1" onClick={() => window.open('/qr/demo', '_blank')}>
                        <LinkIcon className="w-4 h-4 ml-2" /> فتح الصفحة
                      </Button>
                    </div>

                    <div className="w-full bg-blue-50 p-4 rounded-lg text-sm text-blue-700 flex gap-2 items-start text-right">
                      <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5 ml-2" />
                      <div>
                        <p className="font-medium mb-1">معاينة فقط</p>
                        <p className="opacity-90">اضغط على زر "حفظ التغييرات" في الأعلى لحفظ إعداداتك.</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}