import { useParams } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { MessageCircle, AlertTriangle, Lock } from 'lucide-react';
import { motion } from 'framer-motion';
import { useState, useEffect } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { EffectCards, Pagination } from 'swiper/modules';
import logo from '@assets/generated_images/modern_abstract_logo_for_qrista_saas_with_qr_code_elements.png';

export default function PublicQR() {
  const { id } = useParams();
  const [whatsapp, setWhatsapp] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [publicImages, setPublicImages] = useState<string[]>([]);
  const [isExpired, setIsExpired] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [notes, setNotes] = useState('');

  // Load data from localStorage simulation
  useEffect(() => {
    const savedWhatsapp = localStorage.getItem('qrista_whatsapp');
    const savedName = localStorage.getItem('qrista_business_name');
    const savedPublicImages = localStorage.getItem('qrista_public_images');
    const savedStatus = localStorage.getItem('qrista_subscription_status');

    if (savedWhatsapp) setWhatsapp(savedWhatsapp);
    if (savedName) setBusinessName(savedName);
    if (savedPublicImages) setPublicImages(JSON.parse(savedPublicImages));
    if (savedStatus === 'expired') setIsExpired(true);
  }, []);

  const handleSendOrder = () => {
    if (!whatsapp) {
      alert("لم يقم صاحب العمل بإعداد رقم واتساب بعد.");
      return;
    }

    // "مرحباً، اسمي [name] وأرغب بطلب: [order]"
    const message = `مرحباً، اسمي ${customerName} وأرغب بطلب: ${notes}`;
    const url = `https://wa.me/${whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  if (isExpired) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4" dir="rtl">
        <Card className="max-w-md w-full text-center p-8 shadow-xl">
          <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-6">
            <Lock className="w-8 h-8 text-red-500" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">الخدمة متوقفة</h1>
          <p className="text-muted-foreground mb-6">
            رمز QR هذا غير نشط حالياً لانتهاء صلاحية الاشتراك.
          </p>
          <div className="text-sm text-gray-400">
            يرجى التواصل مع صاحب العمل مباشرة.
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white md:bg-gray-50 flex flex-col items-center py-8 px-4" dir="rtl">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-white md:shadow-xl md:rounded-3xl overflow-hidden min-h-[80vh] flex flex-col"
      >
        {/* Header / Branding */}
        <div className="p-6 bg-white border-b sticky top-0 z-10 flex items-center justify-between shadow-sm">
           <div className="flex items-center gap-2">
             <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <img src={logo} className="w-6 h-6 object-contain" />
             </div>
             <div>
               <h1 className="font-bold text-lg leading-tight">{businessName || "اسم المتجر"}</h1>
               <span className="text-xs text-muted-foreground">قائمة الطلبات</span>
             </div>
           </div>
        </div>

        {/* Content */}
        <div className="flex-1 p-6 space-y-8 overflow-y-auto">
           {/* Image Carousel (Swiper) */}
           <div className="rounded-2xl bg-gray-50 min-h-[250px] flex items-center justify-center shadow-inner py-4">
             {publicImages.length > 0 ? (
               <Swiper
                 effect={'cards'}
                 grabCursor={true}
                 modules={[EffectCards, Pagination]}
                 pagination={{ clickable: true }}
                 className="w-full max-w-[320px] aspect-[3/4]" // Standard aspect ratio for menus
               >
                 {publicImages.map((img, idx) => (
                   <SwiperSlide key={idx} className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100">
                     <div className="w-full h-full flex items-center justify-center bg-white">
                        <img 
                          src={img} 
                          alt={`Page ${idx + 1}`} 
                          className="w-full h-full object-contain" 
                        />
                     </div>
                   </SwiperSlide>
                 ))}
               </Swiper>
             ) : (
               <div className="text-center p-8 text-gray-400">
                 <AlertTriangle className="w-10 h-10 mx-auto mb-2 opacity-50" />
                 <p className="text-sm">لم يتم رفع صور القائمة بعد.</p>
               </div>
             )}
           </div>

           {/* Order Form */}
           <div className="space-y-4">
             <h2 className="text-xl font-bold text-primary flex items-center gap-2">
               <MessageCircle className="w-5 h-5" />
               إرسال طلب جديد
             </h2>
             
             <div className="space-y-2">
               <Label htmlFor="name">الاسم الكريم</Label>
               <Input 
                 id="name" 
                 placeholder="مثال: محمد أحمد" 
                 value={customerName}
                 onChange={(e) => setCustomerName(e.target.value)}
                 className="bg-gray-50 border-gray-200"
               />
             </div>

             <div className="space-y-2">
               <Label htmlFor="notes">تفاصيل الطلب / ملاحظات</Label>
               <Textarea 
                 id="notes" 
                 placeholder="مثال: 1 بيتزا خضار حجم كبير، 2 بيبسي..." 
                 className="min-h-[100px] bg-gray-50 border-gray-200 resize-none"
                 value={notes}
                 onChange={(e) => setNotes(e.target.value)}
               />
             </div>
           </div>
        </div>

        {/* Footer Actions */}
        <div className="p-6 bg-white border-t sticky bottom-0 z-10 pb-8 md:pb-6">
          <Button 
            size="lg" 
            className="w-full h-14 text-lg rounded-xl bg-[#25D366] hover:bg-[#128C7E] text-white shadow-lg shadow-green-500/20 transition-all hover:scale-[1.02]"
            onClick={handleSendOrder}
            disabled={!customerName || !notes}
          >
            <MessageCircle className="w-6 h-6 ml-2" />
            إرسال الطلب عبر واتساب
          </Button>
          <p className="text-center text-xs text-muted-foreground mt-4">
            سيتم تحويلك إلى تطبيق واتساب لإرسال الرسالة.
          </p>
        </div>
      </motion.div>
    </div>
  );
}