import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Check, Zap, BarChart3, ShieldCheck } from 'lucide-react';
import { Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default function Home() {
  const { t } = useTranslation();

  const fadeIn = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6 }
  };

  const plans = [
    {
      name: "الأساسية",
      price: "$1",
      period: t('pricing.monthly'),
      features: ["رمز QR مخصص واحد", "تحليلات أساسية", "دعم فني قياسي"],
      popular: false,
      color: "bg-gray-50 border-gray-200"
    },
    {
      name: "المحترف",
      price: "$5.50",
      period: t('pricing.sixmonth'),
      features: ["5 رموز QR مخصصة", "تحليلات متقدمة", "دعم فني ذو أولوية", "ربط مباشر بواتساب"],
      popular: true,
      color: "bg-white border-primary shadow-xl shadow-primary/10"
    },
    {
      name: "الأعمال",
      price: "$10",
      period: t('pricing.yearly'),
      features: ["عدد غير محدود من الرموز", "تحليلات فورية", "دعم 24/7", "هوية تجارية مخصصة"],
      popular: false,
      color: "bg-gray-50 border-gray-200"
    }
  ];

  return (
    <div className="min-h-screen pt-24 pb-12 overflow-x-hidden" dir="rtl">
      {/* Hero Section */}
      <section className="container mx-auto px-4 mb-24">
        <div className="max-w-4xl mx-auto text-center relative">
          <div className="absolute -top-20 -right-20 w-64 h-64 bg-primary/20 rounded-full blur-[100px] animate-pulse" />
          <div className="absolute top-10 -left-20 w-72 h-72 bg-secondary/20 rounded-full blur-[100px] animate-pulse delay-1000" />
          
          <motion.div {...fadeIn} className="relative z-10">
            <Badge variant="outline" className="mb-6 px-4 py-1.5 border-primary/20 text-primary bg-primary/5 rounded-full text-sm">
              جديد: ربط مباشر مع واتساب للأعمال 🚀
            </Badge>
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6 leading-[1.2]">
              {t('hero.title')} <br />
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary via-secondary to-accent animate-gradient-x">
                للأعمال
              </span>
            </h1>
            <p className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed">
              {t('hero.subtitle')}
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/signup">
                <Button size="lg" className="h-14 px-8 rounded-full text-lg bg-gradient-to-r from-primary to-secondary hover:opacity-90 hover:scale-105 transition-all shadow-lg shadow-primary/25">
                  {t('hero.cta')}
                </Button>
              </Link>
              <Link href="/demo">
                 <Button variant="outline" size="lg" className="h-14 px-8 rounded-full text-lg border-2 hover:bg-secondary/5">
                  شاهد العرض التوضيحي
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="container mx-auto px-4 mb-32">
        <div className="grid md:grid-cols-3 gap-8">
          {[
            { icon: Zap, title: "تواصل فوري", desc: "مسحة واحدة لفتح محادثة واتساب مباشرة." },
            { icon: BarChart3, title: "تحليلات ذكية", desc: "تتبع من يمسح رموزك ومتى." },
            { icon: ShieldCheck, title: "منصة آمنة", desc: "أمان بمستوى المؤسسات لبياناتك." }
          ].map((feature, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="p-8 rounded-3xl bg-white border border-gray-100 hover:border-primary/20 hover:shadow-xl hover:shadow-primary/5 transition-all group"
            >
              <div className="w-14 h-14 rounded-2xl bg-primary/5 flex items-center justify-center mb-6 text-primary group-hover:scale-110 transition-transform">
                <feature.icon className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="container mx-auto px-4 mb-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">{t('nav.pricing')}</h2>
          <p className="text-muted-foreground">أسعار بسيطة وشفافة للجميع.</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className={`h-full relative overflow-hidden rounded-3xl border-2 transition-all hover:-translate-y-2 ${plan.color}`}>
                {plan.popular && (
                  <div className="absolute top-0 left-0 bg-gradient-to-br from-primary to-secondary text-white text-xs font-bold px-4 py-1 rounded-br-xl">
                    {t('pricing.most_popular')}
                  </div>
                )}
                <CardHeader className="pb-2">
                  <h3 className="text-xl font-medium text-muted-foreground">{plan.name}</h3>
                  <div className="flex items-baseline gap-1 mt-2">
                    <span className="text-4xl font-bold">{plan.price}</span>
                    <span className="text-muted-foreground">/ {plan.period}</span>
                  </div>
                </CardHeader>
                <CardContent className="pt-6">
                  <ul className="space-y-3">
                    {plan.features.map((feat, j) => (
                      <li key={j} className="flex items-center gap-3 text-sm">
                        <div className="w-5 h-5 rounded-full bg-green-100 text-green-600 flex items-center justify-center flex-shrink-0">
                          <Check className="w-3 h-3" />
                        </div>
                        {feat}
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter className="pt-8">
                  <Button className={`w-full rounded-full h-12 ${plan.popular ? 'bg-gradient-to-r from-primary to-secondary hover:opacity-90' : 'bg-gray-900 hover:bg-gray-800'}`}>
                    اختر باقة {plan.name}
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}